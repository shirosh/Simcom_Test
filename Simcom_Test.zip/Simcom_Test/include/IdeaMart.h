#if (ARDUINO >=100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif
#include "constants.h"

class IdeaMart {
  public:
  unsigned long dataInterval;
  bool readyToSend=false;
  //constructor
  IdeaMart(bool displayMsg=false);

  //methods
  void bootInit();
  void setupGSM();
  //void smsReport(String state);
  //void verifyGPRSCon();
  //bool timeout(const int DELAY, long *previousMillis, bool *flag);
  //bool makeCon(void (*f)());
 /*  bool mqttCon();
  void setupMQTT();
  void cb(char* t, byte* payload, unsigned int l) ;
  void sendEvent();
  void doA(const char* message,String id);
  void fota();
  void health(String id); */
  

  private:
};

//void IRAM_ATTR onTimer();

