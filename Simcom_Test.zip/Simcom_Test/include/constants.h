
#define TINY_GSM_MODEM_SIM7000 // define modem type

#define FIRMWARE_VER    "Vaayu_V1.1"
#define MCU             "ESP32_WROOM_Dev_Module"

#define MQTT_MAX_PACKET_SIZE    512

#define SEALEVELPRESSURE_HPA (1013.25)
#define TIME_INTERVAL 10

//5 seconds scalar
#define TIME_SCALAR 50000
//#define MQTT_CALLBACK_SIGNATURE void (*callback)(char*, uint8_t*, unsigned int)
//#define MQTT_CALLBACK_SIGNATURE std::function<void(char*, uint8_t*, unsigned int)> callback
#define RST_COUNTER     1440

#define IMEI_SIZE       15
#define CCID_SIZE       16

#define SERIAL_RATE     115200

#define EEPROM_ADDR     0
#define RST_ADDR        0
#define INTERVAL_ADDR   1
#define APN_ADDR        2
#define NM_ADDR         3
#define PM_ADDR         4
#define EEPROM_SIZE     256


#define ESP_RST         32

//GSM pin configuration
#define GSM_PWR         12
#define GSM_RX          15
#define GSM_TX          14
#define GSM_RST         13
#define MODEM_RATE      9600

#define TIMEOUT_DELAY   5000


//GSM pin configuration
#define SENSOR_RX       16
#define SENSOR_TX       17
#define SENSOR_RATE     115200
#define TX_ENABLE       5

//ideamart IoT parameters
#define NET_APN         "nbiot"
#define APN_USER        ""
#define APN_PASS        ""
#define HTTP_SERVER     ""
#define HTTP_RESOURCE   ""
#define HTTP_PORT       8080
#define DEVICE_ID       ""

//ideamart mqtt parameters
#define MQTT_BROKER     "mqtt.iot.ideamart.io"
#define MQTT_PORT       1883
//#define ACTION_TOPIC2    "/vaayu/airqualitysensor/v1/sub"


#define INPUT_RES       "\"status\":\"ok\""

//I2C PINS
//SCL   22 
//SDA   21


