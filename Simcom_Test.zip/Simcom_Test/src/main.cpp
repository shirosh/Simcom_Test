#include <Arduino.h>
#include "constants.h"
#include "IdeaMart.h"
//#include "mqtt.h"
#include <Wire.h>




IdeaMart Vaayu(true);
//MQTT mqtt();


void setup() {



  Serial.begin(SERIAL_RATE);
  Vaayu.bootInit();
  Vaayu.setupGSM();
  //Vaayu.smsReport("boot");
  ////Vaayu.setupMQTT();
   
  /* Use 1st timer of 4 */
  /* 1 tick take 1/(80MHZ/80) = 1us so we set divider 80 and count up */
  
  
}

void loop() {

  
  //Vaayu.verifyGPRSCon();
  //Vaayu.mqttCon();
  //delay(1000);
}




