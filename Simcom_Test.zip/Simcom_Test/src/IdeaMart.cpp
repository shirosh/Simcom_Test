#include "constants.h"
#include <TinyGsmClient.h>

#include <EEPROM.h>

#include "IdeaMart.h"



// Hardware serial objects
HardwareSerial SerialGSM(1);
HardwareSerial SerialSensor(2);

// create GSM object
TinyGsm modemGSM(SerialGSM);
TinyGsmClient client(modemGSM);


// timeout flags
//bool flagCon = false, flagUserResp = false;

unsigned int rst_cnt,modemFails, gprsFails, gsmFails,mqttFails,nm,pm;

String ccid,imei,cop;
int    sig, bat,dataSendCount;

char charBuf[100];
char startStr[7];
char dir[7];
char msg[200];

char actionTopic[100]="+/";
char actionResTopic[100]="/";

unsigned int timeCnt=0;
//unsigned int dataInterval;
String apnName;




IdeaMart::IdeaMart(bool displayMsg){
  //Anything yoy need when initiating object goes here
}

void IdeaMart::bootInit(){


  digitalWrite(ESP_RST,HIGH);
  Serial.begin(SERIAL_RATE);
  Serial.println("Booting...");
  pinMode(GSM_PWR,OUTPUT);


  Serial.println("This is a SIM7000 test");
  EEPROM.begin(EEPROM_SIZE);

  
    EEPROM.writeULong(INTERVAL_ADDR, 2);
    EEPROM.commit();
    EEPROM.writeString(APN_ADDR, "dialogbb");
    EEPROM.commit();
    EEPROM.writeUInt(NM_ADDR,13);
    EEPROM.commit();
    EEPROM.writeUInt(PM_ADDR,3);
    EEPROM.commit();

  
  EEPROM.writeUInt(EEPROM_ADDR, 0);
  EEPROM.commit();
  
  //Serial.println("End of setup");
  
}

void IdeaMart::setupGSM()
{
  Serial.println("Setup Connection------>");
  digitalWrite(GSM_PWR,HIGH);
  delay(200);

   // Initiate serial SIM7000
  SerialGSM.begin(MODEM_RATE, SERIAL_8N1, GSM_RX, GSM_TX, false);

  delay(8000); 

  Serial.println("Modem Info------>");
  imei=modemGSM.getIMEI();

  // print Modem model
  Serial.println(modemGSM.getModemInfo());
  Serial.println(imei);

  //Serial.println(modemGSM.getRegistrationStatus());
  //Serial.println(modemGSM.getOperator());
  //Serial.println(imei.length());
  
  
  Serial.println(ccid);
  
  Serial.println(modemGSM.setNetworkMode(13));             // 38-LTE 13-gsm 2-Auto 51-LTE&GSM
  Serial.println(modemGSM.setPreferredMode(3));           //1-CATm 2-NB 3-catm&nb
  


}

